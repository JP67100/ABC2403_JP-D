    VARIABLES 

    somme est un entier
    moyenne est un float
    valeur est un entier et =42
    tableau est un entier de 10 cases 

    TRAITEMENTS

    Initialiser tableau avec les 10 valeurs 
    faire une boucle FOR (int i = 0 ; i < tableau.length ; i++)
    Recuperer somme dans tableau [i]
    Calculer moyenne = somme/10
    Calculer le  carré de 42 

    RESULTATS
   
   ECrire "la moyenne est de :" + moyenne
   ECRIRE "La somme la plus élevé (42) au carré =" + valeur
   
   
   
   
    
